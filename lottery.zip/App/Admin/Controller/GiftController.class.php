<?php
/**
 * Author: huanglele
 * Date: 2016/7/27
 * Time: 下午 10:24
 * Description:
 */

namespace Admin\Controller;

class GiftController extends CommonController
{

    //礼物列表
    public function index()
    {
        $this->display('index');
    }

}