<?php
return array(
	//'配置项'=>'配置值'
    'LAYOUT_ON' => true,
    'LAYOUT_NAME' => 'Public/layout',

    'SHOW_PAGE_TRACE' => true,
);