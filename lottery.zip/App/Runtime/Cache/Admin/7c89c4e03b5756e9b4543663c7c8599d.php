<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head lang="zh">
    <meta charset="UTF-8">
    <title>请登录</title>
    <script src="/lottery/Public/js/jquery-2.1.1.min.js" type="text/javascript"></script>
    <link rel="stylesheet" type="text/css" href="/lottery/Public/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="/lottery/Public/css/admin.css">
    <style>
        .block{
            position: relative;
            width: 350px;
            margin: auto;
        }
        .form{
            padding: 10px 20px;
        }
    </style>
    <script>
        $(window).ready(function(){
            var bodyHeight = $(window).height();
            var _top = (bodyHeight-250)/2;
            $('.block').css('top',_top);
            $('#form').submit(function(){
                var _user = $('input[name="user"]');
                var _pw = $('input[name="pw"]');
                if(_user.val()==''){
                    alert('请填写用户名');
                    _user.focus();
                    return false;
                }
                if(_pw.val()==''){
                    alert('请填写密码');
                    _pw.focus();
                    return false;
                }
                return true;
            });
        });
    </script>
</head>
<body>
<div class="container">
    <div class="block">
        <p class="block-heading">欢迎使用，请先登录！</p>
        <div class="form">
            <form id="form" class="" action="<?php echo U('index/login');?>" method="post">
                <div class="form-group">
                    <label for="user">用户名</label>
                    <input type="text" class="form-control" name="user" id="user" placeholder="请输入用户名">
                </div>
                <div class="form-group">
                    <label for="pw">密码</label>
                    <input type="password" class="form-control" name="pw" id="pw" placeholder="请输入密码">
                </div>
                <input type="hidden" name="submit">
                <button type="submit" class="btn btn-default">登录</button>
            </form>
        </div>
    </div>
</div>
</body>
</html>