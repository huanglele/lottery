<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo ((isset($title) && ($title !== ""))?($title):C('SITE_NAME')); ?></title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" type="text/css" href="/lottery/Public/css/admin.css">
    <!--<link rel="stylesheet" type="text/css" href="/lottery/Public/css/bootstrap.min.css">-->
    <link href="//cdn.bootcss.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">

    <script src="/lottery/Public/js/jquery-2.1.1.min.js" type="text/javascript"></script>
    <!--<script src="http://libs.baidu.com/jquery/1.10.2/jquery.js"></script>-->
    <script src="/lottery/Public/js/bootstrap.min.js" type="text/javascript"></script>

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>

<!--[if lt IE 7 ]> <body class="ie ie6"> <![endif]-->
<!--[if IE 7 ]> <body class="ie ie7"> <![endif]-->
<!--[if IE 8 ]> <body class="ie ie8"> <![endif]-->
<!--[if IE 9 ]> <body class="ie ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<body>
<!--<![endif]-->

<div class="navbar">
    <div class="navbar-inner">
        <div class="container-fluid">.
            <ul class="nav nav-pills pull-right">
                <li><a href="#"><?php echo (session('user')); ?></a></li>
                <li><a href="<?php echo U('common/logout');?>">退出</a></li>
            </ul>
            <a href="/lottery/admin.php" class="brand" ><?php echo ((isset($title) && ($title !== ""))?($title):C('SITE_NAME')); ?>后台管理</a>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-xs-3 col-md-3 col-lg-2">
            <div id="mainNav" class="sidebar-nav">
                <div class="nav-header"><i class="icon-dashboard"></i>用户管理</div>
                <ul class="nav nav-list collapse in">
                    <li ><a href="<?php echo U('User/index');?>">所有用户</a></li>
                    <li ><a href="<?php echo U('User/add');?>">添加球队</a></li>
                </ul>

                <div class="nav-header"><i class="icon-briefcase"></i>信息管理</div>
                <ul class="nav nav-list collapse in">
                    <li ><a href="<?php echo U('Index/wechat');?>">微信信息</a></li>
                    <li ><a href="<?php echo U('Index/pwd');?>">修改密码</a></li>
                    <li ><a href="<?php echo U('Index/listAdmin');?>">管理员列表</a></li>
                    <li ><a href="<?php echo U('Index/addAdmin');?>">添加列表</a></li>
                </ul>

                <div class="nav-header"><i class="icon-dashboard"></i>球队管理</div>
                <ul class="nav nav-list collapse in">
                    <li ><a href="<?php echo U('Team/index');?>">所有球队</a></li>
                    <li ><a href="<?php echo U('Team/add');?>">添加球队</a></li>
                </ul>


                <div class="nav-header"><i class="icon-briefcase"></i>比赛管理</div>
                <ul class="nav nav-list collapse in">
                    <li ><a href="<?php echo U('match/index');?>">所有比赛</a></li>
                    <li ><a href="<?php echo U('match/add');?>">添加比赛</a></li>
                    <li ><a href="<?php echo U('match/record');?>">查看记录</a></li>
                </ul>

            </div>
        </div>
        <div class="col-sm-9 col-md-9 col-lg-10">
            <div class="panel panel-default">
    <div class="panel-heading">
        修改密码
    </div>
    <div class="panel-body">
        <form class="form-horizontal" action="<?php echo U('pwd');?>" method="post" style="margin: 30px auto;">
            <div class="row">
                <div class="col-xs-5 col-sm-offset-3">
                    <div class="form-group">
                        <label class="sr-only" for="pwd">原密码</label>
                        <div class="input-group">
                            <div class="input-group-addon">原密码</div>
                            <input type="password" class="form-control" id="pwd" name="pwd" placeholder="填写原密码" >
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-5 col-sm-offset-3">
                    <div class="form-group">
                        <label class="sr-only" for="newpwd">新密码</label>
                        <div class="input-group">
                            <div class="input-group-addon">新密码</div>
                            <input type="password" class="form-control" id="newpwd" name="newpwd" placeholder="不能和原密码相同" >
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-5 col-sm-offset-3">
                    <div class="form-group">
                        <label class="sr-only" for="repwd"> 确认</label>
                        <div class="input-group">
                            <div class="input-group-addon"> &nbsp;&nbsp;&nbsp;确认</div>
                            <input type="password" class="form-control" id="repwd" name="repwd" placeholder="和新密码相同" >
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-5 col-sm-offset-3">
                    <button type="submit" style="width: 100%" name="submit" class="btn btn-success">修改</button>
                </div>
            </div>
        </form>
    </div>
</div>

        </div>
    </div>

    <footer>
        <hr>
        <p class="pull-right"><a href="tencent://message/?uin=2361547577">联系作者</a></p>
        <p>&copy; 2016</p>
    </footer>
</div>

<!--alert提示消息-->
<div id="msgModal" class="modal fade">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">提示</h3>
            </div>
            <div class="modal-body">
                <p class="content h4"></p>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>
    $(window).ready(function(){
        msgModal = $('#msgModal');
        //时间控件
        $('.form_datetime').each(function(){
            if($(this).attr('data-date')!='undefined'){
                var _dateFmt = $(this).attr('data-date');
            }else{
                var _dateFmt = 'yyyy-mm-dd';
            }
            $(this).datetimepicker({format: _dateFmt,language:'zh-CN'});
        });

        //删除确认
        $('.deleteA').click(function(){
            if(confirm('确定删除？')){
                return true;
            }else{
                return false;
            }
        });
        //导航收缩
        $('.nav-header',$('#mainNav')).each(function(){
            $(this).click(function(){
                $(this).next().slideToggle('show');
            })
        })
    });

    function alertMsg(msg,sec){
        $('.content',msgModal).html(msg);
        msgModal.modal('show');
        if(typeof sec == 'number'){
            setTimeout(function(){msgModal.modal('hide')},sec*1000);
        }
    }

</script>
</body>
</html>