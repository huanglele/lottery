<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?php echo ((isset($title) && ($title !== ""))?($title):C('SITE_NAME')); ?></title>
    <meta content="IE=edge,chrome=1" http-equiv="X-UA-Compatible">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" type="text/css" href="/lottery/Public/css/admin.css">
    <!--<link rel="stylesheet" type="text/css" href="/lottery/Public/css/bootstrap.min.css">-->
    <link href="//cdn.bootcss.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet">

    <script src="/lottery/Public/js/jquery-2.1.1.min.js" type="text/javascript"></script>
    <!--<script src="http://libs.baidu.com/jquery/1.10.2/jquery.js"></script>-->
    <script src="/lottery/Public/js/bootstrap.min.js" type="text/javascript"></script>

    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
    <![endif]-->
</head>

<!--[if lt IE 7 ]> <body class="ie ie6"> <![endif]-->
<!--[if IE 7 ]> <body class="ie ie7"> <![endif]-->
<!--[if IE 8 ]> <body class="ie ie8"> <![endif]-->
<!--[if IE 9 ]> <body class="ie ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<body>
<!--<![endif]-->

<div class="navbar">
    <div class="navbar-inner">
        <div class="container-fluid">.
            <ul class="nav nav-pills pull-right">
                <li><a href="#"><?php echo (session('user')); ?></a></li>
                <li><a href="<?php echo U('common/logout');?>">退出</a></li>
            </ul>
            <a href="/lottery/admin.php" class="brand" ><?php echo ((isset($title) && ($title !== ""))?($title):C('SITE_NAME')); ?>后台管理</a>
        </div>
    </div>
</div>

<div class="container-fluid">
    <div class="row">
        <div class="col-xs-3 col-md-3 col-lg-2">
            <div id="mainNav" class="sidebar-nav">
                <div class="nav-header"><i class="icon-dashboard"></i>球队管理</div>
                <ul class="nav nav-list collapse in">
                    <li ><a href="<?php echo U('Team/index');?>">所有球队</a></li>
                    <li ><a href="<?php echo U('Team/add');?>">添加球队</a></li>
                </ul>


                <div class="nav-header"><i class="icon-briefcase"></i>比赛管理<span class="label label-info"></span></div>
                <ul class="nav nav-list collapse in">
                    <li ><a href="<?php echo U('match/index');?>">所有比赛</a></li>
                    <li ><a href="<?php echo U('match/add');?>">添加比赛</a></li>
                </ul>


            </div>
        </div>
        <div class="col-sm-9 col-md-9 col-lg-10">
            <script type="text/javascript" src="/lottery/Public/js/bootstrap-datetimepicker.min.js"></script>
<script type="text/javascript" src="/lottery/Public/js/bootstrap-datetimepicker.zh-CN.js"></script>
<style>
    .flag_icon {
        height: 20px;
    }
</style>
<div class="row">
    <div class="panel panel-default">
        <div class="panel panel-heading">
            添加比赛
        </div>
        <div class="panel panel-body">
            <form id="matchForm" action="<?php echo U('update');?>" method="post" enctype="multipart/form-data">
                <!--比赛名称、比赛类型-->
                <div class="row">
                    <div class="col-xs-4 col-xs-offset-1">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">赛事名</div>
                                <input type="text" class="form-control must" name="name" placeholder="请填写赛事名" value="<?php echo ($info["name"]); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-4 col-xs-offset-1">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">比赛类型</div>
                                <select name="type" class="form-control">
                                    <?php if(is_array($MatchType)): $i = 0; $__LIST__ = $MatchType;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?><option value="<?php echo ($key); ?>"><?php echo ($v); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <!--主客队信息-->
                <div class="row">
                    <div class="col-xs-4 col-xs-offset-1">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">主队ID</div>
                                <input type="text" class="form-control must" name="host_id" placeholder="请填写主队ID" value="<?php echo ($info["host_id"]); ?>">
                                <div class="input-group-addon" id="hostInfo"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-4 col-xs-offset-1">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">客队ID</div>
                                <input type="text" class="form-control must" name="guess_id" placeholder="请填写客队ID" value="<?php echo ($info["guess_id"]); ?>">
                                <div class="input-group-addon" id="guessInfo"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--开始时间、比赛地点-->
                <div class="row">
                    <div class="col-xs-4 col-xs-offset-1">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">比赛时间</div>
                                <input type="text" data-date="yyyy-mm-dd hh:ii:ss" class="form-control must form_datetime" name="b_time" placeholder="请填写比赛时间" value="<?php echo ($info["b_time"]); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-4 col-xs-offset-1">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">比赛地点</div>
                                <input name="place" type="text" placeholder="填写比赛地点" class="form-control must" value="<?php echo ($info["place"]); ?>" />
                            </div>
                        </div>
                    </div>
                </div>

                <!--赔率-->
                <div class="row">
                    <div class="col-xs-3 col-xs-offset-1">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">主胜赔率</div>
                                <input type="text" class="form-control must" name="rate[win]" placeholder="请填写主胜赔率" value="<?php echo ($info["rate"]["win"]); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">平赔率</div>
                                <input type="text" class="form-control" name="rate[draw]" placeholder="若不存在请忽略" value="<?php echo ($info["rate"]["draw"]); ?>">
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-3">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-addon">客胜赔率</div>
                                <input type="text" class="form-control must" name="rate[lose]" placeholder="请填写客胜赔率" value="<?php echo ($info["rate"]["lose"]); ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <!--前台是否显示-->
                <div class="row">
                    <div class="col-xs-6 col-xs-offset-1">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" name="is_show" <?php if(($info["is_show"]) == "1"): ?>checked='checked'<?php endif; ?> value="1">前台显示(勾选用户才能看到该比赛)
                            </label>
                        </div>
                    </div>
                </div>
                <!--提交-->
                <div class="row">
                    <div class="col-xs-6 col-xs-offset-3">
                        <div class="form-group">
                            <input type="hidden" name="id" value="<?php echo ($info["id"]); ?>">
                            <button type="submit" name="submit" value="update" class="btn btn-success btn-block">修改</button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>

    $(window).ready(function(){

        $('select[name="type"]').val('<?php echo ($info["type"]); ?>');
        getOneTeamInfo('<?php echo ($info["host_id"]); ?>','host');
        getOneTeamInfo('<?php echo ($info["guess_id"]); ?>','guess');

        $('select[name="type"]').on('change',function(){
            $('input[name="host_id"]').val('');
            $('#hostInfo').html('');
            $('input[name="guess_id"]').val('');
            $('#guessInfo').html('');
        })
        $('input[name="host_id"]').on('blur',function(){
            getOneTeamInfo($(this).val(),'host');
        });
        $('input[name="guess_id"]').on('blur',function(){
            getOneTeamInfo($(this).val(),'guess');
        });

        //提交表单
        $('#matchForm').submit(function(e){
            $('input.must').each(function(){
                if($(this).val()==''){
                    var msg = $(this).attr('placeholder');
                    alertMsg(msg);
                    e.preventDefault();
                    return false;
                }
            });
            if($('input[name="host_id"]').val() == $('input[name="guess_id"]').val()){
                alertMsg('主客球队不能为同一球队');
                e.preventDefault();
                return false;
            }
        })
    })

    function getOneTeamInfo(id,t){
        var type = $('select[name="type"]').val();
        $.ajax({
            'url':"<?php echo U('team/getOneTeamInfo');?>",
            'data':{
                'id':id
            },
            'success':function(res){
                if(res.status){
                    if(res.type==type){
                        var html = res.name+'<img src="/lottery/upload/'+res.icon+'" class="flag_icon" />';
                        $('#'+t+'Info').html(html);
                    }else{
                        $('input[name="'+t+'_id"]').val('');
                        alertMsg('球队类型不符合');
                    }
                }else{
                    $('input[name="'+t+'_id"]').val('');
                    alertMsg('球队不存在');
                }
            }
        })
    }

</script>
        </div>
    </div>

    <footer>
        <hr>
        <p class="pull-right"><a href="tencent://message/?uin=2361547577">联系作者</a></p>
        <p>&copy; 2016</p>
    </footer>
</div>

<!--alert提示消息-->
<div id="msgModal" class="modal fade">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h3 class="modal-title">提示</h3>
            </div>
            <div class="modal-body">
                <p class="content h4"></p>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script>
    $(window).ready(function(){
        msgModal = $('#msgModal');
        //时间控件
        $('.form_datetime').each(function(){
            if($(this).attr('data-date')!='undefined'){
                var _dateFmt = $(this).attr('data-date');
            }else{
                var _dateFmt = 'yyyy-mm-dd';
            }
            $(this).datetimepicker({format: _dateFmt,language:'zh-CN'});
        });

        //删除确认
        $('.deleteA').click(function(){
            if(confirm('确定删除？')){
                return true;
            }else{
                return false;
            }
        });
        //导航收缩
        $('.nav-header',$('#mainNav')).each(function(){
            $(this).click(function(){
                $(this).next().slideToggle('show');
            })
        })
    });

    function alertMsg(msg,sec){
        $('.content',msgModal).html(msg);
        msgModal.modal('show');
        if(typeof sec == 'number'){
            setTimeout(function(){msgModal.modal('hide')},sec*1000);
        }
    }

</script>
</body>
</html>