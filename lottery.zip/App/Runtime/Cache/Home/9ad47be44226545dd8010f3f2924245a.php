<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN" style="font-size:120px;">
<head>
    <title>篮球·彩票</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="/lottery/Public/css/global.css" rel="stylesheet"/>
    <link href="/lottery/Public/css/football.css" rel="stylesheet"/>
    <script src="/lottery/Public/js/jquery-2.1.1.min.js" type="text/javascript"></script>
    <style>
        .cpm-main-nav .active {
            color: #ff7962;
        }
        .cpm-main-nav .active span:after {
            background-color: #f9664d;
        }
        .cpm-odds-list .cpm-btn.active, .cpm-odds-list .active .cpm-btn {
            background-color: #f9664d;
        }
        .cpm-bets-toolbar .cpm-btn-primary {
            background-color: #f9664d;
            border-color: #f9664d;
            color: #fff;
        }
        .cpm-bets-toolbar .val{
            color: #f9664d;
        }
    </style>
</head>
<body>
<div class="m-loading-mod" id="loading2" style="display: none;">
    <div class="m-loading">
        <i class="i-loading"></i>
    </div>
</div>
<section class="cpm-content cpm-fixed-hd show-recommend">
    <!--头部信息-->
    <header class="header">
    <nav class="cpm-main-nav nav__entry">
        <div class="bd">
            <a href="<?php echo U('hot');?>" <?php if(($active) == "hot"): ?>class="active"<?php endif; ?> >
            <span>热门</span></a>
            <a href="<?php echo U('index');?>" <?php if(($active) == "all"): ?>class="active"<?php endif; ?> >
            <span>全部</span></a>
            <a href="<?php echo U('finish');?>" <?php if(($active) == "finish"): ?>class="active"<?php endif; ?> >
            <span>已结束</span></a>
        </div>
    </nav>
    <div class="user-info">
        <div class="avatar avatar__user">
            <img src="<?php echo (session('headimgurl')); ?>" alt="">
        </div>
        <ul class="cpm-hide">
            <li class="user-list_item">
                <span>金豆：</span>
                <span class="value leftCoinNum"><?php echo (session('coin')); ?></span>
            </li>
            <li class="user-list_item">
                <i class="i i-limit"></i>
                <a href="<?php echo U('index/sign');?>">
                    <span>签到得豆</span>
                </a>
            </li>
            <li class="user-list_item">
                <i class="i i-star i-star__user"></i>
                <a href="<?php echo U('gift/index');?>">
                    <span>兑换礼物</span>
                </a>
            </li>
            <li class="user-list_item">
                <i class="i i-record"></i>
                <a href="<?php echo U('myGuess');?>">
                    <span>竞猜记录</span>
                </a>
            </li>
            <li class="user-list_item">
                <i class="i i-quest"></i>
                <a href="<?php echo U('help');?>">
                    <span>玩法说明</span>
                </a>
            </li>
            <!--<li class="user-list_item">
                <i class="i i-home"></i>
                <span>返回娱乐大厅</span>
            </li>-->
        </ul>
    </div>
</header>

    <?php if(empty($data)): ?><!--没有赛事数据-->
        <div class="main main__finished">
            <div class="mod-empty">
                <i class="i-empty i-empty__future" ></i>
                <div class="desc">
                    <p>暂无赛事</p>
                    <p class="sm">点击头像，返回大厅</p></div>
            </div>
            <div class="main-bd">
                <div class="tab-content tab__league"></div>
            </div>
        </div>

        <?php else: ?>
        <!--列表-->
        <div class="main main__future" id="matchList">
            <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="tab-content tab__league">
                    <div class="mod mod-fold">
                        <div class="mod-hd">
                            <h4 class="mod-hd_title"><span><?php echo ($vo["name"]); ?></span><span class="time"><?php echo ($vo["b_time"]); ?></span></h4>
                        </div>
                        <div class="main-bd">
                            <div class="tab-content tab__league">
                                <div class="mod-bd">
                                    <div class="league">
                                        <ul class="league-list">
                                            <a href="<?php echo U('match');?>?id=<?php echo ($vo["id"]); ?>">
                                                <li class="league-item mod__finished league-seal">
                                                    <div class="item-info game-status">
                                                        <p class="game-state">
                                                            <?php echo ($vo["result"]); ?>
                                                        </p>
                                                    </div>
                                                    <div class="item-info team-info">
                                                        <div class="team">
                                                            <span class="team-logo">
                                                                <img src="<?php echo ($vo["host_icon"]); ?>" class="logo">
                                                            </span>
                                                            <span class="team-name"><?php echo ($vo["host_name"]); ?></span>
                                                            <span class="cpm-hide"></span>
                                                            <span class="team-score"></span>
                                                        </div>

                                                        <div class="team">
                                                            <span class="team-logo">
                                                                <img src="<?php echo ($vo["guess_icon"]); ?>" class="logo">
                                                            </span>
                                                            <span class="team-name"><?php echo ($vo["guess_name"]); ?></span>
                                                            <span class="team-score"></span>
                                                        </div>

                                                        <p class="team-follow">
                                                            <span class="num"><?php echo ($vo["times"]); ?></span>
                                                            <span>人次竞猜</span></p>
                                                    </div>

                                                    <div class="item-info review">回顾</div>
                                                </li>
                                            </a>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><?php endforeach; endif; else: echo "" ;endif; ?>
            
        </div><?php endif; ?>

</section>
</body>
<script>
    leftCoinNum = '<?php echo (session('coin')); ?>';
    //显示头像
    $('.user-info').click(function () {
        var ul = $('.user-info>ul');
        if (ul.hasClass('cpm-hide')) {
            ul.removeClass('cpm-hide').addClass('user-list');
        } else {
            ul.removeClass('user-list').addClass('cpm-hide');
        }
    });

    var page = 2;
    var hasMore = true;
    $(window).ready(function(){

        $(window).scroll(function(){
            totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop());
            if ($(document).height() <= totalheight){
                getMatchList();
                console.log($(window).height());
            }
        })

    });

    function getMatchList(){
        if(hasMore){
            $.ajax({
                url:"<?php echo U('getMatchList');?>",
                data:{
                    p:page,
                    'ac':'finish',
                    'type':2
                },
                beforeSend:function(){
                    $('#loading2').css('display','block');
                    $('#loading2 .m-loading').html('<i class="i-loading"></i>');
                },
                success:function(data){
                    hasMore = false;
                    var url = "<?php echo U('match');?>";
                    if(data.status=='success'){
                        if(data.num>0){
                            var html = '';
                            $.each(data.list,function(i,vo){
                                html += '<div class="tab-content tab__league"><div class="mod mod-fold"><div class="mod-hd"><h4 class="mod-hd_title"><span>'+vo.name+'</span><span class="time">'+vo.b_time+'</span></h4></div><div class="main-bd"><div class="tab-content tab__league"><div class="mod-bd"><div class="league"><ul class="league-list"><a href="'+url+'?id='+vo.id+'"><li class="league-item"><div class="item-info game-status"><p class="game-state">'+vo.result+'</p></div><div class="item-info team-info"><div class="team"><span class="team-logo"><img src="'+vo.host_icon+'"class="logo"></span><span class="team-name">'+vo.host_name+'</span><span class="cpm-hide"></span><span class="team-score"></span></div><div class="team"><span class="team-logo"><img src="'+vo.guess_icon+'"class="logo"></span><span class="team-name">'+vo.guess_name+'</span><span class="team-score"></span></div><p class="team-follow"><span class="num">'+vo.times+'</span><span>人次竞猜</span></p></div><div class="item-info review">回顾</div></li></a></ul></div></div></div></div></div></div>';
                            })
                            $('#matchList').append(html);
                            if(data.num==10){
                                hasMore = true;
                            }
                        }else {
                            $('#loading2 .m-loading').html('<p>没有数据了</p>');
                        }
                        page = data.page;
                    }else {
                        $('#loading2 .m-loading').html('<p>系统错误</p>');
                    }
                },
                'complete':function(){
                    setTimeout(function(){
                        $('#loading2').css('display','none');
                    },1500)
                }
            })
        }else {
            $('#loading2 .m-loading').html('<p>没有数据了</p>');
            setTimeout(function(){
                $('#loading2').css('display','none');
            },1500);
        }
    }


</script>
</html>