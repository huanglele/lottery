<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN" style="font-size:120px;">
<head>
    <title>足球·彩票</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="/lottery/Public/css/global.css" rel="stylesheet"/>
    <link href="/lottery/Public/css/football.css" rel="stylesheet"/>
    <script src="/lottery/Public/js/jquery-2.1.1.min.js" type="text/javascript"></script>
    <style>
        .main__multi {
            padding-top: 0;
            margin-bottom: 150px;
        }
        .cpm-guess-list{
            width: 2000px; transition-duration: 300ms; transform: translate3d(0px, 0px, 0px);
        }
        .cpm-guess-item{
            float:left;width:400px;vertical-align:top;
        }
    </style>
</head>
<body>
<div class="m-loading-mod" id="loading2" style="display: none;">
    <div class="m-loading">
        <i class="i-loading"></i>
    </div>
</div>
<section class="cpm-content cpm-fixed-hd show-recommend">
    <!--头部信息-->
    <header class="header">
<nav class="cpm-main-nav nav__entry">
    <div class="bd">
        <a href="<?php echo U('hot');?>" <?php if(($active) == "hot"): ?>class="active"<?php endif; ?> >
            <span>热门</span></a>
        <a href="<?php echo U('index');?>" <?php if(($active) == "all"): ?>class="active"<?php endif; ?> >
            <span>全部</span></a>
        <a href="<?php echo U('finish');?>" <?php if(($active) == "finish"): ?>class="active"<?php endif; ?> >
            <span>已结束</span></a>
    </div>
</nav>
<div class="user-info">
    <div class="avatar avatar__user">
        <img src="<?php echo (session('headimgurl')); ?>" alt="">
    </div>
    <ul class="cpm-hide">
        <li class="user-list_item">
            <span>金豆：</span>
            <span class="value leftCoinNum"><?php echo (session('coin')); ?></span>
            <a>充值</a>
        </li>
        <li class="user-list_item">
            <i class="i i-limit"></i>
            <span>限时抢兑</span></li>
        <li class="user-list_item">
            <i class="i i-star i-star__user"></i>
            <span>我关注的</span>
            <span class="cpm-hide">0</span>
        </li>
        <li class="user-list_item">
            <i class="i i-record"></i>
            <span>竞猜记录</span>
        </li>
        <li class="user-list_item">
            <i class="i i-quest"></i>
            <span>玩法说明</span>
        </li>
        <li class="user-list_item cpm-hide">
            <i class="i i-download"></i>
            <span>APP下载</span>
        </li>
        <li class="user-list_item">
            <i class="i i-home"></i>
            <span>返回娱乐大厅</span>
        </li>
    </ul>
</div>
</header>

    <?php if(empty($data)): ?><!--没有赛事数据-->
        <div class="main main__finished">
            <div class="mod-empty">
                <i class="i-empty i-empty__future" ></i>
                <div class="desc">
                    <p>暂无赛事</p>
                    <p class="sm">点击头像，返回大厅</p></div>
            </div>
            <div class="main-bd">
                <div class="tab-content tab__league"></div>
            </div>
        </div>

        <?php else: ?>
        <!--列表-->
        <div class="main main__future" id="matchList">
            <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="tab-content tab__league">
                    <div class="mod mod-fold">
                        <div class="mod-hd">
                            <h4 class="mod-hd_title"><span><?php echo ($vo["name"]); ?></span><span class="time"><?php echo ($vo["b_time"]); ?></span></h4>
                        </div>
                        <div class="main-bd">
                            <div class="tab-content tab__league">
                                <div class="mod-bd">
                                    <div class="league">
                                        <ul class="league-list">
                                            <a href="<?php echo U('match');?>?id=<?php echo ($vo["id"]); ?>">
                                                <li class="league-item">
                                                    <div class="item-info game-status">
                                                        <p class="game-time"><?php echo ($vo["name"]); ?></p>
                                                        <p class="game-state">
                                                            <?php echo ($vo["result"]); ?>
                                                        </p>
                                                        <!--<i class="i i-star"></i>-->
                                                    </div>
                                                    <div class="item-info team-info">
                                                        <div class="team">
                                                    <span class="team-logo">
                                                        <img src="<?php echo ($vo["host_icon"]); ?>" class="logo">
                                                    </span>
                                                            <span class="team-name"><?php echo ($vo["host_name"]); ?></span>
                                                            <span class="cpm-hide"></span>
                                                            <span class="team-score"></span>
                                                        </div>
                                                        <div class="team">
                                                    <span class="team-logo">
                                                        <img src="<?php echo ($vo["guess_icon"]); ?>" class="logo">
                                                    </span>
                                                            <span class="team-name"><?php echo ($vo["guess_name"]); ?></span>
                                                            <span class="team-score"></span>
                                                        </div>
                                                        <p class="team-follow">
                                                            <span class="num"><?php echo ($vo["times"]); ?></span>
                                                            <span>人次竞猜</span></p>
                                                    </div>
                                                    <div class="item-info odds-list">
                                                        <div class="odds-list_item">
                                                            <p class="info">主胜</p>
                                                            <p class="odds"><?php echo ($vo["rate"]["win"]); ?></p></div>
                                                        <div class="odds-list_item">
                                                            <p class="info">平</p>
                                                            <p class="odds"><?php echo ($vo["rate"]["draw"]); ?></p></div>
                                                        <div class="odds-list_item">
                                                            <p class="info">客胜</p>
                                                            <p class="odds"><?php echo ($vo["rate"]["lose"]); ?></p></div>
                                                    </div>
                                                </li>
                                            </a>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><?php endforeach; endif; else: echo "" ;endif; ?>

            <!--
             <div class="mod mod-fold fold">
                    <div class="mod-hd">
                        <h4 class="mod-hd_title"><span>明天</span><span class="time">07月23日周六</span></h4>
                        <p class="mod-hd_desc"><span class="count">18场</span>
                            <i class="i i-arrow__down"></i>
                        </p>
                    </div>
                    <div class="main-bd">
                        <div class="tab-content tab__league">
                            <div class="mod-bd">
                                <div class="league">
                                    <ul class="league-list">
                                        <li class="league-item">
                                            <div class="item-info game-status">
                                                <p class="game-time">挪超</p>
                                                <p class="game-state">01:00</p>
                                                <i class="i i-star"></i>
                                            </div>
                                            <div class="item-info team-info" data-pe="tap:_lg.ball.goMatch" data-matchid="8607750">
                                                <div class="team">
                <span class="team-logo">
                  <img src="//888.qq.com/new_images/ver1.2/newdata/teamimg/betm007_team_img498.gif" class="logo"></span>
                                                    <span class="team-name">布兰</span>
                                                    <span class="cpm-hide"></span>
                                                    <span class="team-score"></span>
                                                </div>
                                                <div class="team">
                <span class="team-logo">
                  <img src="//888.qq.com/new_images/ver1.2/newdata/teamimg/betm007_team_img1280.gif" class="logo"></span>
                                                    <span class="team-name">阿勒桑</span>
                                                    <span class="team-score"></span>
                                                </div>
                                                <p class="team-follow">
                                                    <span class="num">2081</span>
                                                    <span>人竞猜</span></p>
                                            </div>
                                            <div class="item-info odds-list">
                                                <div class="odds-list_item" data-pe="tap:lg.ball.select" data-matchid="8607750" data-index="0" data-playname="spf">
                                                    <p class="info">主胜</p>
                                                    <p class="odds">1.42</p></div>
                                                <div class="odds-list_item" data-pe="tap:lg.ball.select" data-matchid="8607750" data-index="1" data-playname="spf">
                                                    <p class="info">平</p>
                                                    <p class="odds">4.00</p></div>
                                                <div class="odds-list_item" data-pe="tap:lg.ball.select" data-matchid="8607750" data-index="2" data-playname="spf">
                                                    <p class="info">客胜</p>
                                                    <p class="odds">6.15</p></div>
                                            </div>
                                            <div class="cpm-hide" data-pe="tap:lg.ball.tips" data-tips="seal">
                                                <i class="i-question">?</i>
                                                <span>封盘中</span></div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            -->

        </div><?php endif; ?>

</section>
</body>
<script>
    leftCoinNum = '<?php echo (session('coin')); ?>';
    //显示头像
    $('.user-info').click(function () {
        var ul = $('.user-info>ul');
        if (ul.hasClass('cpm-hide')) {
            ul.removeClass('cpm-hide').addClass('user-list');
        } else {
            ul.removeClass('user-list').addClass('cpm-hide');
        }
    });

    var page = 2;
    var hasMore = true;
    $(window).ready(function(){

        $(window).scroll(function(){
            totalheight = parseFloat($(window).height()) + parseFloat($(window).scrollTop());
            if ($(document).height() <= totalheight){
                getMatchList();
                console.log($(window).height());
            }
        })

    });

    function getMatchList(){
        if(hasMore){
            $.ajax({
                url:"<?php echo U('getMatchList');?>",
                data:{
                    p:page,
                    'ac':'all',
                    'type':2
                },
                beforeSend:function(){
                    $('#loading2').css('display','block');
                    $('#loading2 .m-loading').html('<i class="i-loading"></i>');
                },
                success:function(data){
                    hasMore = false;
                    var url = "<?php echo U('match');?>";
                    if(data.status=='success'){
                        if(data.num>0){
                            var html = '';
                            $.each(data.list,function(i,vo){
                                html += '<div class="tab-content tab__league"><div class="mod mod-fold"><div class="mod-hd"><h4 class="mod-hd_title"><span>'+vo.name+'</span><span class="time">'+vo.b_time+'</span></h4></div><div class="main-bd"><div class="tab-content tab__league"><div class="mod-bd"><div class="league"><ul class="league-list"><a href="'+url+'?id='+vo.id+'"><li class="league-item"><div class="item-info game-status"><p class="game-time">'+vo.name+'</p><p class="game-state">'+vo.result+'</p><!--<i class="i i-star"></i>--></div><div class="item-info team-info"><div class="team"><span class="team-logo"><img src="'+vo.host_icon+'"class="logo"></span><span class="team-name">'+vo.host_name+'</span><span class="cpm-hide"></span><span class="team-score"></span></div><div class="team"><span class="team-logo"><img src="'+vo.guess_icon+'"class="logo"></span><span class="team-name">'+vo.guess_name+'</span><span class="team-score"></span></div><p class="team-follow"><span class="num">'+vo.times+'</span><span>人次竞猜</span></p></div><div class="item-info odds-list"><div class="odds-list_item"><p class="info">主胜</p><p class="odds">'+vo.rate.win+'</p></div><div class="odds-list_item"><p class="info">平</p><p class="odds">'+vo.rate.draw+'</p></div><div class="odds-list_item"><p class="info">客胜</p><p class="odds">'+vo.rate.lose+'</p></div></div></li></a></ul></div></div></div></div></div></div>';
                            })
                            $('#matchList').append(html);
                            if(data.num==10){
                                hasMore = true;
                            }
                        }else {
                            $('#loading2 .m-loading').html('<p>没有数据了</p>');
                        }
                        page = data.page;
                    }else {
                        $('#loading2 .m-loading').html('<p>系统错误</p>');
                    }
                },
                'complete':function(){
                    setTimeout(function(){
                        $('#loading2').css('display','none');
                    },1500)
                }
            })
        }else {
            $('#loading2 .m-loading').html('<p>没有数据了</p>');
            setTimeout(function(){
                $('#loading2').css('display','none');
            },1500);
        }
    }


</script>
</html>