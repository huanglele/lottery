<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN">
<head>
    <title>球赛说明</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <style>
        body {
            background-color: #252834;
            color: #cedaff;
        }
    </style>
</head>
<body>
<section>
    <?php echo (htmlspecialchars_decode($value)); ?>
</section>
</body>
</html>