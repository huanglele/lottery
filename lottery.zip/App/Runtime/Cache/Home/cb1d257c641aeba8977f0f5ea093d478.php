<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-CN" style="font-size:120px;">
<head>
    <title>篮球·彩票</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="/lottery/Public/css/global.css" rel="stylesheet"/>
    <link href="/lottery/Public/css/football.css" rel="stylesheet"/>
    <script src="/lottery/Public/js/jquery-2.1.1.min.js" type="text/javascript"></script>
    <style>
        .cpm-main-nav .active {
            color: #ff7962;
        }
        .cpm-main-nav .active span:after {
            background-color: #f9664d;
        }
        .cpm-odds-list .cpm-btn.active, .cpm-odds-list .active .cpm-btn {
            background-color: #f9664d;
        }
        .cpm-bets-toolbar .cpm-btn-primary {
            background-color: #f9664d;
            border-color: #f9664d;
            color: #fff;
        }
        .cpm-bets-toolbar .val{
            color: #f9664d;
        }
    </style>
</head>
<body>
<div class="m-loading-mod" id="loading2" style="display: none;">
    <div class="m-loading">
        <i class="i-loading"></i>
    </div>
</div>
<section>
    <!--头部信息-->
    <header class="header">
<nav class="cpm-main-nav nav__entry">
    <div class="bd">
        <a href="<?php echo U('hot');?>" <?php if(($active) == "hot"): ?>class="active"<?php endif; ?> >
            <span>热门</span></a>
        <a href="<?php echo U('index');?>" <?php if(($active) == "all"): ?>class="active"<?php endif; ?> >
            <span>全部</span></a>
        <a href="<?php echo U('finish');?>" <?php if(($active) == "finish"): ?>class="active"<?php endif; ?> >
            <span>已结束</span></a>
    </div>
</nav>
<div class="user-info">
    <div class="avatar avatar__user">
        <img src="<?php echo (session('headimgurl')); ?>" alt="">
    </div>
    <ul class="cpm-hide">
        <li class="user-list_item">
            <span>金豆：</span>
            <span class="value leftCoinNum"><?php echo (session('coin')); ?></span>
            <a>充值</a>
        </li>
        <li class="user-list_item">
            <i class="i i-limit"></i>
            <span>限时抢兑</span></li>
        <li class="user-list_item">
            <i class="i i-star i-star__user"></i>
            <span>我关注的</span>
            <span class="cpm-hide">0</span>
        </li>
        <li class="user-list_item">
            <i class="i i-record"></i>
            <span>竞猜记录</span>
        </li>
        <li class="user-list_item">
            <i class="i i-quest"></i>
            <span>玩法说明</span>
        </li>
        <li class="user-list_item cpm-hide">
            <i class="i i-download"></i>
            <span>APP下载</span>
        </li>
        <li class="user-list_item">
            <i class="i i-home"></i>
            <span>返回娱乐大厅</span>
        </li>
    </ul>
</div>
</header>

    <?php if(empty($data)): ?><!--没有赛事数据-->
        <div class="main main__finished">
            <div class="mod-empty">
                <i class="i-empty i-empty__future" ></i>
                <div class="desc">
                    <p>暂无热门赛事</p>
                    <p class="sm">点击全部，查看更多赛事</p></div>
            </div>
            <div class="main-bd">
                <div class="tab-content tab__league"></div>
            </div>
        </div>

        <?php else: ?>
        <!--列表-->
        <div class="main main__multi cpm-g-single">
            <script>
                var match = new Array();
            </script>
            <div style="margin: .35rem auto .13rem"></div>
            <?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><div class="cpm-slider">
                <div class="cpm-guess-list">
                    <div class="cpm-guess-item">
                       <!-- <div class="guess-status">
                            <i class="i i-star" data-matchid="<?php echo ($vo["id"]); ?>"></i>
                        </div>-->
                        <div class="guess-hd">
                            <div class="guess-hd_item" data-matchid="<?php echo ($vo["id"]); ?>">
                                <h4 class="cate"><?php echo ($vo["name"]); ?></h4>
                                <p class="meta"><?php echo ($vo["b_time"]); ?></p></div>
                        </div>
                        <script>
                            match['<?php echo ($vo["id"]); ?>'] = {'win':"<?php echo ($vo["rate"]["win"]); ?>",'draw':"<?php echo ($vo["rate"]["draw"]); ?>",'lose':"<?php echo ($vo["rate"]["lose"]); ?>",'pk':"<?php echo ($vo["host_name"]); ?>VS<?php echo ($vo["guess_name"]); ?>",'name':"<?php echo ($vo["name"]); ?>"};
                        </script>
                        <div class="guess-bd">
                            <div class="cpm-odds-list">
                                <div class="item option" data-pe="win" data-matchid="<?php echo ($vo["id"]); ?>">
                                    <span class="team-logo">
                                        <img src="<?php echo ($vo["host_icon"]); ?>" class="logo">
                                    </span>
                                    <a href="javascript:void(0);" class="cpm-btn cpm-btn-default">
                                        <strong class="title"><?php echo ($vo["host_name"]); ?></strong>
                                        <div class="desc">
                                            <span class="info">胜</span>
                                            <span class="odds"><?php echo ($vo["rate"]["win"]); ?></span>
                                        </div>
                                    </a>
                                </div>
                                <div class="item" data-pe="draw" data-matchid="<?php echo ($vo["id"]); ?>">

                                </div>
                                <div class="item option" data-pe="lose" data-matchid="<?php echo ($vo["id"]); ?>">
                                <span class="team-logo">
                                    <img src="<?php echo ($vo["guess_icon"]); ?>" class="logo">
                                </span>
                                    <a href="javascript:void(0);" class="cpm-btn cpm-btn-default">
                                        <strong class="title"><?php echo ($vo["guess_name"]); ?></strong>
                                        <div class="desc">
                                            <span class="info">胜</span>
                                            <span class="odds"><?php echo ($vo["rate"]["lose"]); ?></span>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="guess-ft">
                            <p class="team-follow"><?php echo ($vo["times"]); ?>人次竞猜</p>
                            <div class="cpm-hide">
                                <i class="i-question">?</i>
                                <span><?php echo ($vo["result"]); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="<?php echo match;?>?id=<?php echo ($vo["id"]); ?>" class="next"></a>
            </div><?php endforeach; endif; else: echo "" ;endif; ?>

            <!--
            <div class="cpm-slider">
                <div class="cpm-guess-list" data-reactid=".d.4:1.1.0"
                     style="width: 2000px; transition-duration: 300ms; transform: translate3d(0px, 0px, 0px);">
                    <div class="cpm-guess-item" style="float:left;width:400px;vertical-align:top;">
                        <div class="guess-status">
                            <i class="i i-star"></i>
                        </div>
                        <div class="guess-hd">
                            <div class="guess-hd_item" data-pe="tap:_lg.ball.goMatch" data-matchid="9509257">
                                <h4 class="cate">国际冠军杯</h4>
                                <p class="meta">明天 20:00</p></div>
                        </div>
                        <div class="guess-bd">
                            <div class="cpm-odds-list">
                                <div class="item" data-pe="tap:lg.ball.select" data-matchid="9509257" data-index="0"
                                     data-playname="spf">
                                <span class="team-logo">
                                    <img src="//888.qq.com/new_images/ver1.2/newdata/teamimg/betm007_team_img27_c.gif" class="logo"></span><a href="javascript:void(0);" class="cpm-btn cpm-btn-default">
                                    <strong class="title">曼联</strong>
                                    <div class="desc">
                                        <span class="info">胜</span>
                                        <span class="odds">2.10</span>
                                    </div>
                                </a>
                                </div>
                                <div class="item" data-pe="tap:lg.ball.select" data-playname="spf">
                                    <a href="javascript:void(0);" class="cpm-btn cpm-btn-default">
                                        <strong class="title">平</strong>
                                        <div class="desc">
                                            <span class="info">平</span>
                                            <span class="odds">3.25</span>
                                        </div>
                                    </a>
                                </div>
                                <div class="item" data-pe="tap:lg.ball.select">
                                <span class="team-logo">
                                    <img src="//888.qq.com/new_images/ver1.2/newdata/teamimg/betm007_team_img99_c.gif" class="logo">
                                </span>
                                    <a href="javascript:void(0);" class="cpm-btn cpm-btn-default">
                                        <strong class="title">多特蒙德</strong>
                                        <div class="desc">
                                            <span class="info">胜</span>
                                            <span class="odds">2.95</span>
                                        </div>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="guess-ft">
                            <p class="team-follow">5488人竞猜</p>
                            <div class="cpm-hide">
                                <i class="i-question">?</i>
                                <span>封盘中</span>
                            </div>
                        </div>
                    </div>
                </div>
                <a href="javascript:void(0);" class="next"></a>
            </div>
            -->

            <footer class="footer cpm-fixed cpm-fixed-b">
                <div class="cpm-hide" id="footerBet">
                    <div class="hd">
                        <span class="counts">
                          <i class="i i-bean"></i>
                          <span class="leftCoinNum"><?php echo (session('coin')); ?></span>
                          <span class="plus"></span>
                        </span>

                            <div class="result">猜对可以赢</span>
                                <span class="val" id="reward" style="overflow:auto;max-width:none;"></span></div>
                            <i class="cpm-bets-close"></i>
                    </div>
                    <div class="bd">
                        <div class="bets-list bets-list__multiple" id="divScroll" style="overflow: hidden; height: 50px;">
                            <ul style="transition-property: transform; transform-origin: 0px 0px 0px; transform: translate(0px, 0px) translateZ(0px);">
                                <li class="bets-list_item">
                                    <span id="pk"></span>
                                    <span class="bets-list_type" id="bets-list_type"></span>
                                </li>
                            </ul>
                        </div>
                        <div class="cpm-btn-group">
                            <div class="cpm-bets-options">
                                <div class="layout-col">
                                    <div class="cpm-dropdown cpm-dropdown__gq" id="cpm-dropdown__gq">
                                        <a href="javascript:void(0);" class="dd-toggle">
                                            <span>投200金豆</span>
                                            <input type="hidden" name="cost" value="200">
                                            <input type="hidden" name="option" value="">
                                            <input type="hidden" name="matchid" value="">
                                            <input type="hidden" name="rate" value="">
                                            <i class="caret"></i>
                                        </a>
                                        <ul class="dd-menu">
                                            <li data-value="2000">投2000金豆</li>
                                            <li data-value="1000">投1000金豆</li>
                                            <li data-value="500">投500金豆</li>
                                            <li data-value="200">投200金豆</li>
                                            <li data-value="100">投100金豆</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <a href="javascript:void(0);" id="sureBuyBtn" class="cpm-btn cpm-btn-large cpm-btn-primary">确认下注</a></div>
                    </div>
                </div>
            </footer>

        </div><?php endif; ?>

</section>
</body>
<script>
    leftCoinNum = '<?php echo (session('coin')); ?>';
    //显示头像
    $('.user-info').click(function () {
        var ul = $('.user-info>ul');
        if (ul.hasClass('cpm-hide')) {
            ul.removeClass('cpm-hide').addClass('user-list');
        } else {
            ul.removeClass('user-list').addClass('cpm-hide');
        }
    });

    //点击选择球队
    $('.cpm-odds-list>.option').click(function(){
        var item = $(this);
        if(item.hasClass('active')){
            $('.cpm-odds-list>.item').removeClass('active');
            //取消选择的球队
            $('#footerBet').addClass('cpm-hide').removeClass('cpm-bets-toolbar');   //隐藏footer下注
        }else{
            $('.cpm-odds-list>.item').removeClass('active');
            //选中球队
            item.addClass('active');
            chooseTeam(item);
        }
    })

    //选择中球队
    function chooseTeam(item){
        var matchid = item.attr('data-matchid');
        var pe = item.attr('data-pe');
        var info = match[matchid];
        var rate = info[pe];
        var best;
        if (pe=='win'){
           best = '主胜';
        }else if (pe == 'draw'){
            best = '平';
        }else if(pe == 'lose'){
            best = '客胜';
        }else{
            return false;
        }
        $('input[name="matchid"]').val(matchid);  //记录选择
        $('input[name="option"]').val(pe);  //记录选择
        $('input[name="rate"]').val(rate);  //记录选择
        $('#pk').html(info.pk);
        $('#bets-list_type').html(best+'（'+rate+'）');
        updateCost();
        $('#footerBet').addClass('cpm-bets-toolbar').removeClass('cpm-hide');
    }

    //更新回报金蛋数
    function updateCost(){
        var rate = $('input[name="rate"]').val();
        var cost = $('input[name="cost"]').val();
        var reward = rate * cost;
        $('#reward').html(reward+'金豆');

    }

    function log(s){
        console.log(s);
    }

    //点击确认下载按钮
    $('#sureBuyBtn').click(function(){
        var matchid = $('input[name="matchid"]').val();
        var option = $('input[name="option"]').val();
        var rate = $('input[name="rate"]').val();
        var cost = $('input[name="cost"]').val();
        if(rate*cost > leftCoinNum){
            //金豆数量不足
            alert('金豆不足');
        }else{
            $.ajax({
                'data':{
                    'matchid':matchid,
                    'option':option,
                    'cost':cost
                },
                'type':'post',
                'beforeSend':function(){
                    $('#loading2').css('display','block');
                    $('#loading2 .m-loading').html('<i class="i-loading"></i>');
                },
                'url':"<?php echo U('buyBall');?>",
                'success':function(res){
                    if(res.status=='success'){
                        leftCoinNum = res.coin;
                        $('.leftCoinNum').html(leftCoinNum);
                    }
                    $('#loading2 .m-loading').html('<p>'+res.msg+'</p>');
                },
                'complete':function(){
                    setTimeout(function(){
                        $('.cpm-bets-close').click();
                        $('#loading2').css('display','none');
                    },1500)
                }
            })
        }
    });

    //关闭选择
    $('.cpm-bets-close').click(function(){
        $('.cpm-odds-list>.item').removeClass('active');
        $('#footerBet').addClass('cpm-hide').removeClass('cpm-bets-toolbar');
    })

    //选择金额
    $('#cpm-dropdown__gq').click(function(){
        if($(this).hasClass('active')){
            $(this).removeClass('active');
        }else{
            $(this).addClass('active');
        }
    })
    $('#cpm-dropdown__gq li').click(function(){
        $('#cpm-dropdown__gq span').html($(this).html());
        $('input[name="cost"]').val($(this).attr('data-value'));
        updateCost();
        $('#cpm-dropdown__gq').removeClass('active');
        return false;   //必须加上 阻止事件冒泡
    })
</script>
</html>